"""FastAPI routes and authentication."""

from wowasi_ya.api.routes import router

__all__ = ["router"]
