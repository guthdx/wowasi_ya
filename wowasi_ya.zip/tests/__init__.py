"""Tests for Wowasi_ya."""
